#!/bin/sh

echo "stopping anthill services"
/etc/init.d/S15timezone stop
/etc/init.d/S12hwscan stop
/etc/init.d/S71monitor stop
/etc/init.d/S70miner stop
/etc/init.d/S80dashd stop

echo "extracting overlay files"
tar -xzf /nvdata/anthillos/overlay.tar.gz -C /

echo "starting anthill services"
/etc/init.d/S15timezone start
/etc/init.d/S12hwscan start
/etc/init.d/S80dashd start
/etc/init.d/S70miner start
/etc/init.d/S71monitor start
